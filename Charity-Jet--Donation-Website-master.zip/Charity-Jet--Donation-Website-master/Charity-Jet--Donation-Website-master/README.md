# tarini--Donation-Website
tarini is a Donation Website with integrated payment gateway using Razorpay. 
